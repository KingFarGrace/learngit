package practice1;

class Employee {
	int id;
	String name;
	public Employee(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	public void printInfo() {
		System.out.println("Ա�����Ϊ: " + id + " Ա������Ϊ: " + name);
	}
}

class Manager extends Employee {
	String deName;
	public Manager(int id, String name, String deName) {
		super(id, name);
		this.deName = deName;
	}
	
	@Override
	public void printInfo() {
		System.out.println("���ܱ��Ϊ: " + id + " ��������Ϊ: " + name + " ���ܲ���Ϊ: " + deName);
	}
}

public class TestEmployee {
	public static void main(String[] args) {
		Employee e = new Employee(1, "Jack");
		Manager m = new Manager(2, "Tom", "CS");
		e.printInfo();
		m.printInfo();
	}
}

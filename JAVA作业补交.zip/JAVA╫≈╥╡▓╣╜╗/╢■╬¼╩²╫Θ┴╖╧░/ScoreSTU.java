package practice6;
import java.util.Scanner;

public class ScoreSTU {
	
	private double getSum(double[] scoreList) {
		double sum = 0;
		for(double score : scoreList) {
			sum += score;
		}
		return sum;
	}
	
	private double getAvg(double[] scoreList) {
		double avg = 0;
		avg = getSum(scoreList) / scoreList.length;
		return avg;
	}
	
	public static void main(String[] args) {
		ScoreSTU ss = new ScoreSTU();
		Scanner sc = new Scanner(System.in);
		double[][] scoreList = new double[4][3];
		System.out.println("��������������ѧ��A,B,C�γ̳ɼ�:");
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < 3; j++) {
				scoreList[i][j] = sc.nextDouble();
			}
		}
		
		for(int i = 0; i < 4; i++) {
			System.out.println("��" + (i+1) + "��ͬѧ�ܳɼ�Ϊ: " + ss.getSum(scoreList[i]) + " ƽ���ɼ�Ϊ: " + ss.getAvg(scoreList[i]));
		}
		
		sc.close();
	}
}

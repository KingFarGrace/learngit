package practice1;
import java.lang.Math;
public class PrimeNum {
	public static void main(String[] args) {
		int start = 101,end = 199;
		System.out.println("101-199֮�������Ϊ: ");
		getPrimeNumber(start,end);
	}
	
	public static void getPrimeNumber(int start, int end) {
		int i = 2;
		for(int index = start; index <= end; index ++) {
			for(; i <= Math.sqrt(index); i++) {
				if(index % i == 0) {
					break;
				}//end_if
			}//end_for
			
			if(i <= Math.sqrt(index)) {
				System.out.print(index + " ");
			}//end_if
		}//end_for
	}
}

package practice6;
import java.util.Scanner;

class STU{
		private String name;
		private int id;
		private int age;
		private String sex;
		
		protected STU(String name, int id, int age, String sex) {
			this.name = name;
			this.id = id;
			this.age = age;
			this.sex = sex;
		}
		
		public void printInfo() {
			System.out.println("����Ϊ: " + name + " ѧ��Ϊ: " + id + " ����Ϊ: " + age + " �Ա�Ϊ:" + sex);
		}
}

public class ArraySTU {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String name;
		int id;
		int age;
		String sex;
		STU[] s = new STU[4];
		for(int i = 0; i < 4; i++) {
			System.out.print("�������" + (i + 1) + "��ѧ����������ѧ�ţ����䣬�Ա�: ");
			name = sc.next();
			id = sc.nextInt();
			age = sc.nextInt();
			sex = sc.next();
			s[i] = new STU(name, id, age, sex);
		}
		
		for(int i = 0; i < 4; i++) {
			System.out.print("��" + (i + 1) +  "��ѧ��");
			s[i].printInfo();
		}

		sc.close();
	}
}

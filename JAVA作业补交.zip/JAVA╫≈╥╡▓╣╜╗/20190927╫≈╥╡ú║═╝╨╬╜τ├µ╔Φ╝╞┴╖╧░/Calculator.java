package calculator;

import java.awt.*;

import javax.swing.*;

public class Calculator {
	public static void main(String[] args) {
		new InputBoard();
	}
}

@SuppressWarnings("serial")
class InputBoard extends JFrame{
	JPanel p1;
	
	JTextField f1;
	
	JButton o1;
	JButton o2;
	JButton o3;
	JButton o4;
	JButton o5;
	JButton o6;
	JButton o7;
	JButton o8;
	JButton o9;
	JButton o10;
	JButton o11;
	JButton o12;
	JButton o13;
	JButton o14;
	JButton o15;
	
	JButton n1;
	JButton n2;
	JButton n3;
	JButton n4;
	JButton n5;
	JButton n6;
	JButton n7;
	JButton n8;
	JButton n9;
	JButton n10;
	
	public InputBoard() {	
		Container container = getContentPane();		
		container.setLayout(new BorderLayout());
		
		f1 = new JTextField("");
		f1.setBorder(BorderFactory.createTitledBorder(""));
		f1.setEnabled(false);
		
		p1 = new JPanel(new GridLayout(5, 5, 5, 5));
		p1.setBorder(BorderFactory.createTitledBorder(""));	
		p1.add(o13 = new JButton(""));			o13.setEnabled(false);
		p1.add(o14 = new JButton(""));			o14.setEnabled(false);
		p1.add(o15 = new JButton(""));			o15.setEnabled(false);
		p1.add(o11 = new JButton("Backspace"));	o11.setForeground(Color.RED);
		p1.add(o12 = new JButton("C"));			o12.setForeground(Color.RED);
		p1.add(n1 = new JButton("7"));
		p1.add(n2 = new JButton("8"));
		p1.add(n3 = new JButton("9"));
		p1.add(o1 = new JButton("/"));			o1.setForeground(Color.RED);
		p1.add(o2 = new JButton("("));			o2.setForeground(Color.RED);
		p1.add(n4 = new JButton("4"));
		p1.add(n5 = new JButton("5"));		
		p1.add(n6 = new JButton("6"));
		p1.add(o3 = new JButton("*"));			o3.setForeground(Color.RED);
		p1.add(o4 = new JButton(")"));			o4.setForeground(Color.RED);
		p1.add(n7 = new JButton("1"));
		p1.add(n8 = new JButton("2"));
		p1.add(n9 = new JButton("3"));
		p1.add(o5 = new JButton("-"));			o5.setForeground(Color.RED);
		p1.add(o6 = new JButton("["));			o6.setForeground(Color.RED);
		p1.add(n10 = new JButton("0"));
		p1.add(o7 = new JButton("="));			o7.setForeground(Color.RED);
		p1.add(o8 = new JButton("."));			o8.setForeground(Color.RED);
		p1.add(o9 = new JButton("+"));			o9.setForeground(Color.RED);
		p1.add(o10 = new JButton("]"));			o10.setForeground(Color.RED);	
		
		
		container.add(f1, BorderLayout.NORTH);
		container.add(p1, BorderLayout.CENTER);
		setSize(800, 300);
		setTitle("������");
		setVisible(true);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	}
}


package practice1;

import java.util.Scanner;

public class GcdAndLcm {
	public static void main(String[] args) {

		Scanner sc = new Scanner (System.in);
		System.out.println("��������a:");
		int a = sc.nextInt();
		System.out.println("��������b:");
		int b = sc.nextInt();
		try {
			int gcd = gcd(a, b);
			int lcm = lcm(a, b);
			System.out.println("��С������Ϊ: " + lcm + "\t���Լ��Ϊ: " + gcd);
		} catch (ArithmeticException ae) {
			ae.printStackTrace();
			System.out.println("��������Ϊ�㣡");
		} finally {
			sc.close();
		}
	}
	
	public static int gcd (int a, int b) throws ArithmeticException {
		int i = (a < b) ? a : b;
		if (b % i == 0 && a % i == 0) {
			return i;
		}
		for (; i > 0; i--) {
			if (a % i == 0 && b % i == 0) {
				break;
			}
		}
		return i;
	}
	
	public static int lcm (int a, int b) throws ArithmeticException {
		int i = (a > b) ? a : b;
		if (i % b == 0 && i % a == 0) {
			return i;
		}
		for (; i <= a * b; i++) {
			if (i % a == 0 && i % b == 0) {
				break;
			}
		}
		return i;
	}
}

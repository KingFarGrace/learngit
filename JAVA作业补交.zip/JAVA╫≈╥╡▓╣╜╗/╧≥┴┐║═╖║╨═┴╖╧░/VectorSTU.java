package practice6;
import java.util.Enumeration;
import java.util.Scanner;
import java.util.Vector;

class STU1{
	private String name;
	private int id;
	private int age;
	private String sex;
	
	protected STU1(String name, int id, int age, String sex) {
		this.name = name;
		this.id = id;
		this.age = age;
		this.sex = sex;
	}
	
	public void printInfo() {
		System.out.println("����Ϊ: " + name + " ѧ��Ϊ: " + id + " ����Ϊ: " + age + " �Ա�Ϊ:" + sex);
	}
}

public class VectorSTU {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String name;
		int id;
		int age;
		String sex;
		Vector<STU1> stuv = new Vector<>();
		
		for(int i = 0; i < 4; i++) {
			System.out.print("�������" + (i + 1) + "��ѧ����������ѧ�ţ����䣬�Ա�: ");
			name = sc.next();
			id = sc.nextInt();
			age = sc.nextInt();
			sex = sc.next();
			stuv.add(new STU1(name, id, age, sex));
		}
		
		Enumeration<STU1> stuEnum = stuv.elements();
		while(stuEnum.hasMoreElements()) {
			STU1 s = stuEnum.nextElement();
			s.printInfo();
		}
		
		sc.close();
	}
}

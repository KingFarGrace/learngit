package practice7;
import java.util.Scanner;
import java.util.Vector;
import java.util.InputMismatchException;
import java.util.Iterator;

public class Derivative {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double x1 = 0;
		double x2 = 0;
		Vector<Double> v1 = new Vector<>();
		Vector<Double> v2 = new Vector<>();
		System.out.println("����������ÿһ���ϵ����ָ��(ϵ��������0����): ");
		try {
			while(true) {
				x1 = sc.nextDouble();
				v1.add(x1);
				if(x1 == 0) {
					break;
				}
				x2 = sc.nextDouble();
				v2.add(x2);
			} 
		} catch(InputMismatchException e) {
			e.printStackTrace();
		}
		Iterator<Double> it1 = v1.iterator();
		Iterator<Double> it2 = v2.iterator();
		System.out.print("�󵼺�Ķ���ʽΪ:");
		while(it2.hasNext()) {
			double x3 = it1.next();
			double x4 = it2.next();
			x3 *= x4;
			x4--;
			System.out.print(x3 + "x^" + x4 + "+");
		}
		System.out.print("0.0");
		sc.close();
	}
}

package practice2;
import java.util.Scanner;

abstract class Shape {
	public abstract double getPerimetre();
	public abstract double getArea();
}

class Circle extends Shape {
	private final double PI = 3.1415926;
	private double r;
	
	public Circle(double r) {
		this.r = r;
	}
	
	public double getPerimetre() {
		double perimetre;
		perimetre = 2 * PI * r;
		return perimetre;
	}
	
	public double getArea() {
		double area;
		area = PI * r * r;
		return area;
	}
}

class Rectangle extends Shape {
	private double rectLong;
	private double rectWide;
	
	public Rectangle(double rectLong, double rectWide) {
		this.rectLong = rectLong;
		this.rectWide = rectWide;
	}
	
	public double getPerimetre() {
		double perimetre;
		perimetre = 2 * (rectLong + rectWide);
		return perimetre;
	}
	
	public double getArea() {
		double area;
		area = rectLong * rectWide;
		return area;
	}
}

class Square extends Rectangle {
	private double length;
	
	public Square(double length) {
		super(length,length);
		this.length = length;
	}
	
	public double getPerimetre() {
		double perimetre;
		perimetre = 4 * length;
		return perimetre;
	}
	
	public double getArea() {
		double area;
		area = length * length;
		return area;
	}
}

public class TestAbstract {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int index = 0;
		System.out.print("����Բ������1��������������2����������������3:");
		index = sc.nextInt();
		
		switch(index) {
			case 1: System.out.print("������Բ�ΰ뾶:");
					double r = sc.nextDouble();
					Circle c = new Circle(r);
					System.out.println("Բ���ܳ�Ϊ:" + c.getPerimetre() + "Բ�����Ϊ:" + c.getArea());	
					break;
					
			case 2: System.out.print("��������γ��Ϳ�:");
					double rl = sc.nextDouble();
					double rw = sc.nextDouble();
					Rectangle rt = new Rectangle(rl,rw);
					System.out.println("�����ܳ�Ϊ:" + rt.getPerimetre() + "�������Ϊ:" + rt.getArea());	
					break;
					
			case 3: System.out.print("�����������α߳�:");
					double l = sc.nextDouble();
					Square s = new Square(l);
					System.out.println("�������ܳ�Ϊ:" + s.getPerimetre() + "���������Ϊ:" + s.getArea());	
					break;
		}
		
		sc.close();
	}
}

package practice8;
import java.util.InputMismatchException;
import java.util.Scanner;

@SuppressWarnings("serial")
class EmptyStorageException extends Exception {
	
}

class Commodify	{
	public String name;
	public double price;
	public int storeNum;
	
	public Commodify(String name, double price, int storeNum) {
		this.name = name;
		this.price = price;
		this.storeNum = storeNum;
	}
	
	public void print() {
		System.out.println("��Ʒ��Ϊ: " + name + " �۸�Ϊ: " + price + " �����ʣ" + storeNum + "��");
	}
	
	public double purchase(int count) {
		storeNum -= count;
		double sum = count * price;
		return sum;
	}
}

class Food extends Commodify {
	public int freshTime;
	
	public Food(String name, double price, int storeNum, int freshTime) {
		super(name, price, storeNum);
		this.freshTime = freshTime;
	}		
	
	public void print() {
		System.out.println("��Ʒ��Ϊ: " + name + " �۸�Ϊ: " + price + " ������Ϊ " + freshTime + "��" + " �����ʣ" + storeNum + "��");
	}
}

class Clothes extends Commodify {
	public String size;

	public Clothes(String name, double price, int storeNum, String size) {
		super(name, price, storeNum);
		this.size = size;
	}
	
	public void print() {
		System.out.println("��Ʒ��Ϊ: " + name + " �۸�Ϊ: " + price + " ����Ϊ: " + size+ " �����ʣ" + storeNum + "��");
	}
}

public class ShopStimulation {
	public static void main(String[] args) throws EmptyStorageException {
		Scanner sc = new Scanner(System.in);
		Commodify[] cmdList = new Commodify[6];
		cmdList[0] = new Food("FoodA", 12, 7, 20);
		cmdList[1] = new Food("FoodB", 15, 5, 10);
		cmdList[2] = new Food("FoodC", 20, 3, 5);
		cmdList[3] = new Clothes("ClothesA", 100, 10, "S");
		cmdList[4] = new Clothes("ClothesB", 300, 7, "L");
		cmdList[5] = new Clothes("ClothesC", 500, 5, "XL");
		int ynFlag = 1;
		while(ynFlag == 1) {			
			for(Commodify cmd : cmdList) {
				cmd.print();
			}
				
			try {				
					System.out.print("������Ҫ�������Ʒ���ƺ͹�������: ");
					String name = sc.next();
					int count = sc.nextInt();
					int falseIndex = 0;
					
					for(Commodify cmd : cmdList) {
						if(cmd.name.equals(name)) {
							if(cmd.storeNum < count) {
								throw new EmptyStorageException();
							}
							else {
								double sum = cmd.purchase(count);
								System.out.println("�ܽ��Ϊ:" + sum);
							}					
							break;
						}
					
						else {
							falseIndex++;
						}
					}//for
					
					if(falseIndex == 6) {
						System.out.println("δ�ҵ���Ʒ!");
						falseIndex = 0;
					}

				} catch(InputMismatchException e) {
					System.out.println("������Ϣ����!");
			
				} catch(EmptyStorageException e) {
					System.out.println("�������!");
				}//try-catch
						
				System.out.print("�Ƿ����������������1, ��������0: ");
				ynFlag = sc.nextInt();
		
			}//while
		
		sc.close();
	}
}
